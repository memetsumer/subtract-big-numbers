console.log("hello");

// 111111111111111111111111111
// 9999999
//Const subtract = (num1:string, num2:string):string => {}

let bigNumber = "111111111111111111111111111";
let smallNumber = "9999999";

const subtract = (num1: string, num2: string): string => {
  let bigNum = Number.parseInt(num1);

  let num1Result = 0;

  // number1
  let number1 = num1.split("");
  let number2 = num2.split("");
  // number 2

  let counter = 0;

  let eldevar = 0;
  let results: number[] = [];
  while (number1.length > 0 || number2.length > 0) {
    let res;

    if (eldevar === 1) {
      res =
        Number.parseInt(number1.pop()!) - 1 - Number.parseInt(number2.pop()!);
    } else {
      res = Number.parseInt(number1.pop()!) - Number.parseInt(number2.pop()!);
    }

    if (res < 0) {
      eldevar = 1;
      res += 10;
    } else {
      eldevar = 0;
    }

    counter++;
    results.push(res);
  }

  console.log(results);
  return "";
};

console.log(subtract(bigNumber, smallNumber));
